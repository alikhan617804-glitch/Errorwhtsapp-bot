
import "dotenv/config";
import express from "express";
import makeWASocket, {
  Browsers,
  DisconnectReason,
  useMultiFileAuthState,
  makeCacheableSignalKeyStore
} from "@whiskeysockets/baileys";
import pino from "pino";
import qrcode from "qrcode-terminal";
import QRCode from "qrcode";
import fs from "node:fs";
import path from "node:path";
import { fileURLToPath } from "node:url";
import configFile from "../config.json" with { type: "json" };
import { AUTO_REPLIES } from "./replies.js";
import {
  getGroupSettings, setGroupSettings, addWarning,
  clearWarnings, logAction
} from "./db.js";

const __dirname = path.dirname(fileURLToPath(import.meta.url));
fs.mkdirSync(path.join(__dirname, "../data"), { recursive: true });
fs.mkdirSync(path.join(__dirname, "../auth"), { recursive: true });

const C = configFile;
const logger = pino({ level: process.env.LOG_LEVEL || "silent" });
const flood = new Map();
const cooldown = new Map();

function isGroup(jid) { return jid?.endsWith("@g.us"); }
function senderOf(msg) { return msg.key.participant || msg.key.remoteJid; }
function numberOf(jid) { return (jid || "").split("@")[0]; }

function unwrap(m) {
  if (!m) return null;
  if (m.ephemeralMessage?.message) return unwrap(m.ephemeralMessage.message);
  if (m.viewOnceMessage?.message) return unwrap(m.viewOnceMessage.message);
  if (m.viewOnceMessageV2?.message) return unwrap(m.viewOnceMessageV2.message);
  return m;
}

function textOf(msg) {
  const m = unwrap(msg.message);
  return m?.conversation ||
    m?.extendedTextMessage?.text ||
    m?.imageMessage?.caption ||
    m?.videoMessage?.caption ||
    m?.documentMessage?.caption || "";
}

function typeOf(msg) {
  const m = unwrap(msg.message);
  return m ? Object.keys(m)[0] : null;
}

function hasUrl(text) {
  return /(?:https?:\/\/|www\.|chat\.whatsapp\.com\/|t\.me\/|discord\.gg\/)/i.test(text);
}

function badWord(text) {
  const s = text.toLowerCase();
  return C.badWords.some(w => s.includes(w.toLowerCase()));
}

function mediaBlocked(type, settings) {
  const map = {
    imageMessage: "blockImage",
    videoMessage: "blockVideo",
    audioMessage: "blockAudio",
    documentMessage: "blockDocument",
    stickerMessage: "blockSticker"
  };
  return settings.antiMedia && map[type] && C.media[map[type]];
}

function parseCommand(text) {
  if (!text.startsWith(C.prefix)) return null;
  const parts = text.slice(C.prefix.length).trim().split(/\s+/);
  const command = (parts.shift() || "").toLowerCase();
  return { command, args: parts };
}

async function metadata(sock, jid) {
  return sock.groupMetadata(jid);
}

async function isAdmin(sock, jid, user) {
  const md = await metadata(sock, jid);
  const p = md.participants.find(x => x.id === user);
  return !!p && (p.admin === "admin" || p.admin === "superadmin");
}

function owner(user) {
  return C.ownerNumbers.includes(numberOf(user));
}

async function deleteMessage(sock, msg) {
  try { await sock.sendMessage(msg.key.remoteJid, { delete: msg.key }); return true; }
  catch { return false; }
}

async function warn(sock, msg, reason, settings) {
  const jid = msg.key.remoteJid;
  const user = senderOf(msg);
  const count = addWarning(jid, user);
  logAction(jid, user, "WARN", reason);

  if (settings.deleteWarnedMessages) await deleteMessage(sock, msg);

  await sock.sendMessage(jid, {
    text:
`${C.branding.header}

⚠️ *WARNING ${count}/${settings.maxWarnings}*

👤 @${numberOf(user)}
📌 Reason: ${reason}

${C.branding.footer}`,
    mentions: [user]
  });

  if (count >= settings.maxWarnings) {
    try {
      await sock.groupParticipantsUpdate(jid, [user], "remove");
      clearWarnings(jid, user);
      logAction(jid, user, "REMOVE", "Maximum warnings reached");
    } catch {
      await sock.sendMessage(jid, { text: "❌ I could not remove the member. Make sure I am a group admin." });
    }
  }
}

function quotedParticipant(msg) {
  return msg.message?.extendedTextMessage?.contextInfo?.participant;
}

function mentionTarget(msg, args) {
  const q = quotedParticipant(msg);
  if (q) return q;
  const mentioned = msg.message?.extendedTextMessage?.contextInfo?.mentionedJid;
  if (mentioned?.length) return mentioned[0];
  if (args[0]) return `${args[0].replace(/\D/g, "")}@s.whatsapp.net`;
  return null;
}

async function commandHandler(sock, msg, parsed) {
  const jid = msg.key.remoteJid;
  const user = senderOf(msg);
  const { command, args } = parsed;

  if (command === "help" || command === "menu") {
    return sock.sendMessage(jid, { text:
`${C.branding.header}

⚡ *GENERAL*
!help • !ping • !bot • !rules • !reply

🛡️ *MODERATION*
!warn • !kick • !del • !admins
!antilink • !antispam • !antiflood • !antimedia

👑 *GROUP*
!tagall • !groupinfo • !promote • !demote

⚙️ *SETTINGS*
!settings • !set <feature> on/off
!warnings @user • !clearwarn @user

${C.branding.footer}` });
  }

  if (command === "ping") return sock.sendMessage(jid, { text: "🏓 PONG — ALTITUDE 💀 ONLINE" });
  if (command === "bot") return sock.sendMessage(jid, {
    text: `${C.branding.header}\n\n🟢 ONLINE\n💬 ${AUTO_REPLIES.length}+ replies\n🛡️ Moderation enabled\n⚡ Stable mode\n\n${C.branding.footer}`
  });
  if (command === "reply") {
    const r = AUTO_REPLIES[Math.floor(Math.random() * AUTO_REPLIES.length)];
    return sock.sendMessage(jid, { text: r });
  }
  if (command === "rules") return sock.sendMessage(jid, {
    text: "📜 *GROUP RULES*\n\n1. No spam\n2. No unwanted links\n3. Respect members\n4. No abusive content\n5. Follow admin instructions\n\n💀 ALTITUDE SECURITY"
  });

  if (!isGroup(jid)) return;

  const admin = await isAdmin(sock, jid, user);
  if (!admin && !owner(user)) return sock.sendMessage(jid, { text: "⛔ Admin-only command." });

  const settings = getGroupSettings(jid, C.settings);

  if (command === "settings") {
    return sock.sendMessage(jid, { text:
`⚙️ *ALTITUDE SETTINGS*

Anti-Link: ${settings.antiLink ? "ON" : "OFF"}
Anti-Spam: ${settings.antiSpam ? "ON" : "OFF"}
Anti-Flood: ${settings.antiFlood ? "ON" : "OFF"}
Bad Words: ${settings.antiBadWords ? "ON" : "OFF"}
Media Filter: ${settings.antiMedia ? "ON" : "OFF"}
Welcome: ${settings.welcome ? "ON" : "OFF"}
Auto Replies: ${settings.autoReplies ? "ON" : "OFF"}
Max Warnings: ${settings.maxWarnings}`
    });
  }

  if (command === "set") {
    const allowed = ["antiLink","antiSpam","antiFlood","antiBadWords","antiMedia","welcome","goodbye","autoReplies","deleteWarnedMessages"];
    const key = args[0];
    const value = args[1]?.toLowerCase();
    if (!allowed.includes(key) || !["on","off"].includes(value))
      return sock.sendMessage(jid, { text: `Usage: !set ${allowed[0]} on|off` });
    settings[key] = value === "on";
    setGroupSettings(jid, settings);
    return sock.sendMessage(jid, { text: `✅ ${key}: ${settings[key] ? "ON" : "OFF"}` });
  }

  if (command === "antilink" || command === "antispam" || command === "antiflood" || command === "antimedia") {
    const key = {antilink:"antiLink", antispam:"antiSpam", antiflood:"antiFlood", antimedia:"antiMedia"}[command];
    settings[key] = !settings[key];
    setGroupSettings(jid, settings);
    return sock.sendMessage(jid, { text: `⚙️ ${key}: ${settings[key] ? "ON" : "OFF"}` });
  }

  if (command === "warn") {
    const target = mentionTarget(msg, args);
    if (!target) return sock.sendMessage(jid, { text: "Reply to or mention a member." });
    return warn(sock, { ...msg, key: { ...msg.key, participant: target } }, args.slice(1).join(" ") || "Admin warning", settings);
  }

  if (command === "clearwarn") {
    const target = mentionTarget(msg, args);
    if (!target) return sock.sendMessage(jid, { text: "Reply to or mention a member." });
    clearWarnings(jid, target);
    return sock.sendMessage(jid, { text: `✅ Warnings cleared for @${numberOf(target)}`, mentions: [target] });
  }

  if (command === "kick" || command === "remove") {
    const target = mentionTarget(msg, args);
    if (!target) return sock.sendMessage(jid, { text: "Reply to or mention a member." });
    try {
      await sock.groupParticipantsUpdate(jid, [target], "remove");
      logAction(jid, target, "REMOVE", "Admin command");
      return sock.sendMessage(jid, { text: `🚫 Removed @${numberOf(target)}\n\n💀 ALTITUDE`, mentions: [target] });
    } catch {
      return sock.sendMessage(jid, { text: "❌ Removal failed. Ensure the bot is an admin and has permission." });
    }
  }

  if (command === "del" || command === "delete") {
    if (!msg.message?.extendedTextMessage?.contextInfo?.stanzaId)
      return sock.sendMessage(jid, { text: "Reply to the message you want to delete." });
    const c = msg.message.extendedTextMessage.contextInfo;
    await sock.sendMessage(jid, { delete: { remoteJid: jid, fromMe: false, id: c.stanzaId, participant: c.participant } });
    return;
  }

  if (command === "admins") {
    const md = await metadata(sock, jid);
    const admins = md.participants.filter(p => p.admin);
    return sock.sendMessage(jid, {
      text: "👑 *ADMINS*\n\n" + admins.map((p,i)=>`${i+1}. @${numberOf(p.id)}`).join("\n"),
      mentions: admins.map(p=>p.id)
    });
  }

  if (command === "tagall") {
    const md = await metadata(sock, jid);
    const mentions = md.participants.map(p=>p.id);
    const body = args.join(" ") || "Attention everyone 👀";
    return sock.sendMessage(jid, {
      text: `📢 *${body}*\n\n${mentions.map(x=>`@${numberOf(x)}`).join(" ")}`,
      mentions
    });
  }

  if (command === "groupinfo") {
    const md = await metadata(sock, jid);
    return sock.sendMessage(jid, {
      text: `👑 *GROUP INFO*\n\nName: ${md.subject}\nMembers: ${md.participants.length}\nAdmins: ${md.participants.filter(p=>p.admin).length}`
    });
  }

  if (command === "promote" || command === "demote") {
    const target = mentionTarget(msg, args);
    if (!target) return sock.sendMessage(jid, { text: "Reply to or mention a member." });
    try {
      await sock.groupParticipantsUpdate(jid, [target], command);
      return sock.sendMessage(jid, { text: `✅ ${command} successful for @${numberOf(target)}`, mentions:[target] });
    } catch {
      return sock.sendMessage(jid, { text: `❌ Could not ${command} member.` });
    }
  }

  if (command === "warnings") {
    return sock.sendMessage(jid, { text: "Use !clearwarn @user to reset warnings. Warning counts are stored per group." });
  }
}

async function moderate(sock, msg) {
  const jid = msg.key.remoteJid;
  if (!isGroup(jid) || msg.key.fromMe) return;
  const user = senderOf(msg);
  const text = textOf(msg);
  const type = typeOf(msg);
  const settings = getGroupSettings(jid, C.settings);

  let admin = false;
  try { admin = await isAdmin(sock, jid, user); } catch {}

  if (admin || owner(user)) return;

  if (settings.antiLink && hasUrl(text)) {
    const allowed = C.allowedDomains.some(d => text.toLowerCase().includes(d));
    if (!allowed) return warn(sock, msg, "Unwanted link", settings);
  }

  if (settings.antiBadWords && badWord(text)) {
    return warn(sock, msg, "Blocked keyword", settings);
  }

  if (mediaBlocked(type, settings)) {
    return warn(sock, msg, "Blocked media type", settings);
  }

  if (settings.antiFlood) {
    const key = `${jid}:${user}`;
    const now = Date.now();
    const arr = (flood.get(key) || []).filter(t => now - t < settings.flood.windowSeconds * 1000);
    arr.push(now);
    flood.set(key, arr);
    if (arr.length >= settings.flood.messages) {
      flood.set(key, []);
      return warn(sock, msg, "Flood / spam", settings);
    }
  }
}

async function handleMessage(sock, msg) {
  if (!msg.message || msg.key.remoteJid === "status@broadcast") return;
  const jid = msg.key.remoteJid;
  const user = senderOf(msg);
  const text = textOf(msg);

  if (text) {
    const key = `${jid}:${user}`;
    const last = cooldown.get(key) || 0;
    if (Date.now() - last < C.settings.cooldownMs) return;
    cooldown.set(key, Date.now());
  }

  await moderate(sock, msg);

  const parsed = parseCommand(text);
  if (parsed) return commandHandler(sock, msg, parsed);

  if (!isGroup(jid)) return;
  const settings = getGroupSettings(jid, C.settings);
  if (!settings.autoReplies) return;

  const t = text.trim().toLowerCase();
  if (["hi","hello","hey","salam","assalamualaikum"].includes(t)) {
    return sock.sendMessage(jid, { text: AUTO_REPLIES[Math.floor(Math.random()*AUTO_REPLIES.length)] });
  }
}


// =====================================================
// PRIVATE LOGIN DASHBOARD — QR + PAIRING CODE
// =====================================================
const app = express();
const PORT = Number(process.env.PORT || 3000);
const LOGIN_TOKEN = process.env.LOGIN_TOKEN || "";
let latestQr = null;
let pairingCode = null;
let pairingStatus = "WAITING";

function authorized(req) {
  if (!LOGIN_TOKEN) return true;
  return (req.query.token || "") === LOGIN_TOKEN;
}

app.get("/", (req, res) => {
  if (!authorized(req)) return res.status(401).send("Unauthorized");
  res.send(`<!doctype html>
<html><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1">
<title>ALTITUDE 💀 Login</title>
<style>
body{margin:0;background:#080808;color:#eee;font-family:Arial,sans-serif;display:flex;justify-content:center;align-items:center;min-height:100vh}
.card{width:min(680px,92vw);background:#111;border:1px solid #333;border-radius:20px;padding:28px;box-shadow:0 20px 60px #000}
h1{margin:0 0 8px;font-size:30px}.muted{color:#aaa}.box{margin-top:20px;padding:18px;background:#181818;border-radius:14px}
code{font-size:28px;letter-spacing:5px;color:#fff}.qr{background:#fff;padding:12px;border-radius:12px;display:inline-block}
img{max-width:300px}.small{font-size:13px;color:#999}
</style></head><body><div class="card">
<h1>ALTITUDE 💀</h1><div class="muted">ERROR 💀 WhatsApp Bot — secure login</div>
<div class="box"><b>Status:</b> <span id="status">Loading…</span></div>
<div class="box"><b>QR Code</b><div id="qr" style="margin-top:12px"></div></div>
<div class="box"><b>Pairing Code</b><div id="pair" style="margin-top:12px"></div>
<div class="muted">Use your WhatsApp number in international format, without + or spaces.</div></div>
<div class="small">Keep this page, token and pairing code private.</div>
<script>
async function load(){
 try{
  const r=await fetch("login-status"+location.search);
  const x=await r.json();
  document.getElementById("status").textContent=x.status;
  document.getElementById("pair").innerHTML=x.pairingCode?("<code>"+x.pairingCode+"</code>"):"Not available";
  document.getElementById("qr").innerHTML=x.qr?("<div class='qr'><img src='"+x.qr+"'></div>"):"Waiting for QR…";
 }catch(e){document.getElementById("status").textContent="Server unavailable"}
}
setInterval(load,2000); load();
</script></div></body></html>`);
});

app.get("/login-status", (req, res) => {
  if (!authorized(req)) return res.status(401).json({error:"Unauthorized"});
  res.json({status: pairingStatus, pairingCode, qr: latestQr});
});

app.listen(PORT, () => console.log(`ALTITUDE login panel listening on :${PORT}`));

async function start() {
  const { state, saveCreds } = await useMultiFileAuthState("./auth");
  const sock = makeWASocket({
    auth: {
      creds: state.creds,
      keys: makeCacheableSignalKeyStore(state.keys, logger)
    },
    browser: Browsers.ubuntu("Chrome"),
    logger,
    markOnlineOnConnect: false,
    syncFullHistory: false
  });

  // Optional WhatsApp phone-number pairing code.
  // Set PAIRING_NUMBER=923XXXXXXXXXX in the hosting environment.
  if (process.env.PAIRING_NUMBER && !state.creds.registered) {
    try {
      pairingStatus = "REQUESTING PAIRING CODE";
      const phone = process.env.PAIRING_NUMBER.replace(/\D/g, "");
      pairingCode = await sock.requestPairingCode(phone);
      pairingStatus = "PAIRING CODE READY";
      console.log(`Pairing code: ${pairingCode}`);
    } catch (e) {
      pairingStatus = "PAIRING CODE ERROR";
      console.error("Pairing-code request failed:", e?.message || e);
    }
  }


  sock.ev.on("creds.update", saveCreds);

  sock.ev.on("connection.update", ({ connection, lastDisconnect, qr }) => {
    if (qr) {
      pairingStatus = "SCAN QR";
      latestQr = await QRCode.toDataURL(qr);
      qrcode.generate(qr, { small: true });
    }
    if (connection === "open") {
      pairingStatus = "CONNECTED"; pairingCode = null; latestQr = null;
      console.log(`\n${C.branding.header}\n🟢 Connected\n💬 ${AUTO_REPLIES.length}+ replies\n🛡️ Moderation active\n`);
    }
    if (connection === "close") {
      const code = lastDisconnect?.error?.output?.statusCode;
      if (code !== DisconnectReason.loggedOut) {
        console.log("Connection closed; reconnecting...");
        setTimeout(start, 3000);
      } else {
        console.log("Logged out. Remove ./auth and pair again.");
      }
    }
  });

  sock.ev.on("messages.upsert", async ({ messages, type }) => {
    if (type !== "notify") return;
    for (const msg of messages) {
      try { await handleMessage(sock, msg); }
      catch (e) { console.error("message error:", e?.message || e); }
    }
  });

  sock.ev.on("group-participants.update", async ({ id, participants, action }) => {
    const settings = getGroupSettings(id, C.settings);
    if ((action === "add" && settings.welcome) || (action === "remove" && settings.goodbye)) {
      for (const p of participants) {
        const word = action === "add" ? "WELCOME" : "GOODBYE";
        await sock.sendMessage(id, {
          text: `${C.branding.header}\n\n${action === "add" ? "👋" : "👋"} *${word}*\n@${numberOf(p)}\n\n${C.branding.footer}`,
          mentions: [p]
        });
      }
    }
  });
}

start().catch(err => console.error("Fatal:", err));
